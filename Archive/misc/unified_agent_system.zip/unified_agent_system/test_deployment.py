#!/usr/bin/env python3
"""
Quick deployment test for DPNR CrewAI System
Tests basic imports and configuration without running the full server
"""

def test_basic_imports():
    """Test that core modules can be imported"""
    try:
        from agents.therapeutic_agents import TherapeuticAgents
        from crews.mirror_room_crew import MirrorRoomCrew
        from tasks.therapeutic_tasks import TherapeuticTasks
        print("✅ Core imports successful")
        return True
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False

def test_configuration():
    """Test configuration loading"""
    try:
        import os
        gemini_key = os.getenv("GEMINI_API_KEY", "")
        print(f"✅ Configuration: Gemini API Key {'configured' if gemini_key else 'missing'}")
        return bool(gemini_key)
    except Exception as e:
        print(f"❌ Configuration error: {e}")
        return False

def test_agent_creation():
    """Test that agents can be created"""
    try:
        from agents.therapeutic_agents import TherapeuticAgents
        agents = TherapeuticAgents()
        
        # Test creating each agent
        ifs_agent = agents.ifs_agent()
        shadow_agent = agents.shadow_work_agent()
        pardes_agent = agents.pardes_reflection_agent()
        
        print("✅ Agent creation successful")
        print(f"   - IFS Agent: {ifs_agent.role}")
        print(f"   - Shadow Agent: {shadow_agent.role}")
        print(f"   - PaRDeS Agent: {pardes_agent.role}")
        return True
    except Exception as e:
        print(f"❌ Agent creation error: {e}")
        return False

def test_crew_setup():
    """Test crew initialization"""
    try:
        from crews.mirror_room_crew import MirrorRoomCrew
        crew = MirrorRoomCrew()
        print("✅ Mirror Room Crew initialization successful")
        return True
    except Exception as e:
        print(f"❌ Crew setup error: {e}")
        return False

def main():
    """Run all tests"""
    print("🧪 DPNR CrewAI System - Deployment Test")
    print("=" * 50)
    
    tests = [
        ("Basic Imports", test_basic_imports),
        ("Configuration", test_configuration),
        ("Agent Creation", test_agent_creation),
        ("Crew Setup", test_crew_setup)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n🔍 Testing: {test_name}")
        result = test_func()
        results.append(result)
    
    print("\n" + "=" * 50)
    passed = sum(results)
    total = len(results)
    
    if passed == total:
        print(f"🎉 All tests passed! ({passed}/{total})")
        print("\n🚀 System ready for deployment!")
        print("\nNext steps:")
        print("1. Install dependencies: pip install -r requirements.txt")
        print("2. Configure API keys in .env file")
        print("3. Run: uvicorn api:app --reload")
    else:
        print(f"⚠️  Some tests failed ({passed}/{total})")
        print("\n🔧 Fix the issues above before deployment")

if __name__ == "__main__":
    main()