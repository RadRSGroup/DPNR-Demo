import pytest
from crewai import Crew, Task
from unified_agent_system.agents.therapeutic_agents import TherapeuticAgents
from unified_agent_system.tasks.reporting_tasks import ReportingTasks
from unified_agent_system.crews.reporting_crew import ReportingCrew

class TestReportingCrew:
    @pytest.fixture
    def reporting_crew_instance(self):
        return ReportingCrew()

    def test_reporting_agent_creation(self, reporting_crew_instance):
        agent = reporting_crew_instance.therapeutic_agents.reporting_agent()
        assert agent is not None
        assert agent.role == "Insightful Progress Reporter"

    def test_weekly_summary_task_creation(self, reporting_crew_instance):
        agent = reporting_crew_instance.therapeutic_agents.reporting_agent()
        context = {"user_id": "test_user", "context_data": {"week": 1, "interactions": []}}
        task = reporting_crew_instance.reporting_tasks.weekly_summary_task(agent, context)
        assert task is not None
        assert isinstance(task, Task)
        assert task.agent == agent

    def test_create_weekly_soul_summary_crew(self, reporting_crew_instance):
        context = {"user_id": "test_user", "context_data": {"week": 1, "interactions": []}}
        crew = reporting_crew_instance.create_weekly_soul_summary_crew(context)
        assert crew is not None
        assert isinstance(crew, Crew)
        assert len(crew.agents) == 1
        assert crew.agents[0].role == "Insightful Progress Reporter"
        assert len(crew.tasks) == 1
        assert isinstance(crew.tasks[0], Task)

    def test_get_status_method(self, reporting_crew_instance):
        # This tests the placeholder get_status method
        task_id = "test_task_id"
        status = reporting_crew_instance.get_status(task_id)
        assert status is not None
        assert status["status"] == "completed"
        assert "dummy weekly soul summary" in status["result"]["summary"]

    def test_get_status_method_not_found(self, reporting_crew_instance):
        status = reporting_crew_instance.get_status(None)
        assert status is not None
        assert status["status"] == "not_found"